package animator.model;

public enum AnimatorState {
  PAUSE, PLAY
}
