package cs3500.freecell.model;

/**
 * This class represents a color of a card which can either be red or black.
 */
public enum Color {
  RED, BLACK;
}
